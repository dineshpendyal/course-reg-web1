package com.keane.training.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import com.keane.training.dao.SqlMapper;
import com.keane.training.domain.Course;
import com.keane.training.domain.Department;
import com.keane.training.domain.Professor;
import com.keane.training.domain.Student;
import com.keane.dbcon.ConnectionHolder;
import com.keane.dbcon.DBConnectionException;
import com.keane.dbfw.DBFWException;
import com.keane.dbfw.DBHelper;
import com.keane.dbfw.ParamMapper;


public class AdminDAO {
	static Logger log=Logger.getLogger(AdminDAO.class);
	
	/*public String saveProfessor(final Professor prof) throws CourseDAOException, DBConnectionException
	{
	       
		ConnectionHolder ch=null;
		Connection con=null;

			int result=0;
			String sp=null;
			List a1 = null;
			//System.out.println(prof.getProfName());
			
		/*try{
			
			
				a1=(List) DBHelper.executeSelect(con,SQLMapper.PROFESSOR_SEQUENCE,SQLMapper.PROFESSOR_MAP);
		}
		catch (DBFWException e){
			throw new CourseDAOException();
			}
			final String a = (String)((java.util.List)a1).get(0);
			
			try {
				ch=ConnectionHolder.getInstance();
				con=ch.getConnection();
				
				final ParamMapper INSERTPPROFESSOR=new ParamMapper()
				{

					
					public void mapParam(PreparedStatement preStmt)
							throws SQLException {
						//preStmt.setString(1,a);
						preStmt.setString(1,prof.getProfName());
						preStmt.setString(2,prof.getDeptId());
						
					}
					
				};
				
			result=DBHelper.executeUpdate(con,SQLMapper.INSERTPROFESSOR,INSERTPPROFESSOR);
				
				
			} catch (DBFWException e) {
				// TODO Auto-generated catch block
			System.out.println(e);
			} catch (DBConnectionException e) {
				// TODO Auto-generated catch block
				System.out.println(e);
			}
			
			return prof.getProfId();
			
			}*/
	
		
		public String saveProfessor(final Professor prof)throws CourseDAOException, DBConnectionException{
			int result=0;
			String sp=null;
			List a1 = null;
			ConnectionHolder ch=null;
			Connection con=null;
			//con = ch.establishConnection();//
			
			try{ch=ConnectionHolder.getInstance();
			    con=ch.getConnection();
				a1=(List) DBHelper.executeSelect(con,SqlMapper.PROFESSOR_SEQUENCE,SqlMapper.PROFESSOR_MAP);
			}
			catch (DBFWException e){
				throw new CourseDAOException();
			}
			final String a = (String)((java.util.List)a1).get(0);
			ParamMapper INSERTPPROFESSOR = new ParamMapper(){
				public void mapParams(PreparedStatement pStmt) throws SQLException{
					pStmt.setString(1,a);
					pStmt.setString(2,prof.getProfName());
					pStmt.setString(3,prof.getDeptId());
				}
			};
			try {
				ch=ConnectionHolder.getInstance();
				con=ch.getConnection();
				result = DBHelper.executeUpdate(con, SqlMapper.INSERTPROFESSOR,INSERTPPROFESSOR);
//				System.out.println("record inserted.");
			}
			catch (DBFWException e){
		    	throw new CourseDAOException(e);
		    }
			finally{
				try{
					con.close();
				}
				catch (SQLException e){
					throw new CourseDAOException(e);
//					System.out.println(e);
				}
			}
			
			if(result>0){
		    	sp=a;// now sp has profId
		    }
		    return sp;//return profId
		}
		
	
	public String saveCourse( final Course course) throws CourseDAOException, DBConnectionException
	{   
		 
		int result=0;
		String sp=null;
		List a1 = null;
		ConnectionHolder ch=null;
		Connection con=null;
		
	
	try {
		ch=ConnectionHolder.getInstance();
		con=ch.getConnection();
		a1=(List) DBHelper.executeSelect(con,SqlMapper.COURSE_SEQUENCE,SqlMapper.COURSE_MAP);
	}
	catch (DBFWException e){
		throw new CourseDAOException();
	}
	final String a = (String)((java.util.List)a1).get(0);
		final ParamMapper INSERTPCOURSE=new ParamMapper()
		{

			
			public void mapParams(PreparedStatement preStmt)
					throws SQLException {
				preStmt.setString(1,a );
				preStmt.setString(2,course.getCourseName());
				preStmt.setString(3,course.getProfId());
				
			}
			
		};
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			result=DBHelper.executeUpdate(con,SqlMapper.INSERTCOURSE,INSERTPCOURSE);
//			System.out.println("record inserted.");
		}
		

		
		
		catch (DBFWException e){
	    	throw new CourseDAOException(e);
	    }
		finally{
			try{
				con.close();
			}
			catch (SQLException e){
				throw new CourseDAOException(e);
//				System.out.println(e);
			}
		}
		
		if(result>0){
	    	sp=a;// now sp has profId
	    }
	    return sp;//return profId*/
	
	
		
	}
	public String saveStudent(final Student stud) throws CourseDAOException
	{
		ConnectionHolder ch=null;
	    Connection con=null;
	     int result=0;
	
	try {
		ch=ConnectionHolder.getInstance();
		con=ch.getConnection();
		
		final ParamMapper INSERTPSTUDENT=new ParamMapper()
		{

			
			public void mapParams(PreparedStatement preStmt)
					throws SQLException {
				preStmt.setString(1,stud.getStudentId() );
				preStmt.setString(2,stud.getStudentName());
				preStmt.setString(3,stud.getAddress());
				preStmt.setDate(4, new java.sql.Date(stud.getDob().getTime()));
				preStmt.setString(5,stud.getDegree());
				
				
			}
			
		};
		
	result=DBHelper.executeUpdate(con,SqlMapper.INSERTSTUDENT,INSERTPSTUDENT);
		
		
	} catch (DBFWException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (DBConnectionException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return stud.getStudentId();
	}
	public List<Department> getAllDept() throws CourseDAOException,DBFWException,DBConnectionException
	{
		List departments=null;
		ConnectionHolder ch=null;
		Connection con=null;
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			log.debug("fetchig");
			departments=DBHelper.executeSelect(con,SqlMapper.FETCHDEPARTMENT,SqlMapper.DEPARTMENTMAPPER);
					
		} catch (DBConnectionException e) {
			throw new DBConnectionException("Unable to connect to db"+e);
		
		}
		finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}
		
		
		return departments;
		
		
		
	}
	public List<Professor> getAllProf() throws CourseDAOException,DBFWException,DBConnectionException
	{
		List professors=null;
		ConnectionHolder ch=null;
		Connection con=null;
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			log.debug("fetchig");
			professors=DBHelper.executeSelect(con,SqlMapper.FETCHPROFESSOR,SqlMapper.PROFESSORMAPPER);
					
		} catch (DBConnectionException e) {
			throw new DBConnectionException("Unable to connect to db"+e);
		
		}
		finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}
		
		
		return professors;
	}
	/*public static List getCountries() throws DBFWException, CountryDAOException, DBConnectionException
	{
		List countries=null;
		ConnectionHolder ch=null;
		Connection con=null;
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			log.debug("fetchig");
			countries=DBHelper.executeSelect(con,SQLMapper.FETCHCOUNTRY,SQLMapper.COUNTRYMAPPER);
					
		} catch (DBConnectionException e) {
			throw new DBConnectionException("Unable to connect to db"+e);
		
		}
		finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}
		
		
		return countries;
		
	}//
*/	
	
	
	
	
	
}
