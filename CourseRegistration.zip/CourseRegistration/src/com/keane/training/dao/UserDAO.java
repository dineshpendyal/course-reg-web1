package com.keane.training.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;


import com.keane.dbcon.ConnectionHolder;
import com.keane.dbcon.DBConnectionException;
import com.keane.dbfw.DBFWException;
import com.keane.dbfw.DBHelper;
import com.keane.training.domain.User;

public class UserDAO {
public User validateUser(String userId,String passwd) throws CourseDAOException, SQLException, ClassNotFoundException
{      User user01;
       String username;
       String password;
       String rollId;
       
		Class.forName("oracle.jdbc.driver.OracleDriver");
	
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","TRDB","TRDB");

		Statement stmt=con.createStatement();
		//stmt.executeUpdate("insert into ntdata values(100)");
		
			  
     
	 if (userId != null) {
            //Statement stmt=con.createStatement();
          String sql = "Select * from user12 Where userId='" + userId + "'";
           ResultSet rs = stmt.executeQuery(sql);
           rs.next();
          username = rs.getString(2);
        password = rs.getString(3);
        rollId=rs.getString(4);
         //user01=new User(userId,username,password,rollId);
        user01=new User(userId,username,password,rollId);
        //System.out.println(userId+" "+username+" "+password+" "+rollId);
        } else{
        	user01=new User("abc","abc","abc","abc");
        	System.out.println("entered else");
        }
           

   return user01;
}







}
