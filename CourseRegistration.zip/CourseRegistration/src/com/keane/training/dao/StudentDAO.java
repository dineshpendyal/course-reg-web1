package com.keane.training.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import com.keane.dbcon.ConnectionHolder;
//import com.ntt.dao.SQLMapper;
//import com.ntt.dao.SQLMapper;

import com.keane.dbcon.DBConnectionException;
import com.keane.dbfw.DBFWException;
import com.keane.dbfw.DBHelper;
import com.keane.dbfw.ParamMapper;
import com.keane.training.domain.Course;
import com.keane.training.domain.CoursePreference;
import com.keane.training.domain.StudPreference;

public class StudentDAO {
	static Logger log=Logger.getLogger(AdminDAO.class);
	public List<Course> getAllCourse() throws CourseDAOException,DBFWException,DBConnectionException{
		List courses=null;
		ConnectionHolder ch=null;
		Connection con=null;
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			log.debug("fetchig");
			courses=DBHelper.executeSelect(con,SqlMapper.FETCHCOURSE,SqlMapper.COURSEMAPPER);
			
		
			System.out.println(courses);
					
		} catch (DBConnectionException e) {
			throw new DBConnectionException("Unable to connect to db"+e);
		
		}
		finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}
		
		
		return courses;
	}
	public int saveCoursePref( final StudPreference studPref) throws CourseDAOException
	
	{
		ConnectionHolder ch=null;
		Connection con=null;
		int result=0;
		
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			final ParamMapper INSERTPCOURSEPREFERENCE=new ParamMapper()
			{

				
				public void mapParams(PreparedStatement preStmt)
						throws SQLException {
					preStmt.setString(1, studPref.getStudId());
					preStmt.setString(2,studPref.getPrefCourse().get(0).getCourseId());
					preStmt.setString(3,studPref.getPrefCourse().get(0).getPrefCourse());

					
					
				}
				
			};
			
		result=DBHelper.executeUpdate(con,SqlMapper.INSERTCOURSEPREFERENCE,INSERTPCOURSEPREFERENCE);
			
			
		} catch (DBFWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
		
		
	}//insert
	
	public List<CoursePreference> getPrefCourses(final String studId) throws CourseDAOException, DBFWException, DBConnectionException
	
	{
		List<CoursePreference> preferences=null;
		ConnectionHolder ch=null;
		Connection con=null;
		ParamMapper mapParam= new ParamMapper(){
			public void mapParams(PreparedStatement pStmt) throws SQLException{
				pStmt.setString(1,studId);
			}
		};
		
		
		
		
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			log.debug("fetchig");
			preferences=DBHelper.executeSelect(con,SqlMapper.FETCHPREFERENCE,mapParam,SqlMapper.PREFERENCEMAPPER);
					
		} catch (DBConnectionException e) {
			throw new DBConnectionException("Unable to connect to db"+e);
		
		}
		finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}
		
		
		return preferences;
		
	}//getcoursePreferences
		
	/*public int saveCoursePref(final StudPreference studPref)throws CourseDAOException, DBFWException, DBConnectionException {
		CoursePreference cp=new CoursePreference();
		Connection con=null;
		int result=0;
	//
		StudPreference sp=new StudPreference();
		//V
		int noOfEntries=studPref.getPrefCourse().size();
		for (int i = 0; i < noOfEntries; i++) {
			
		//^
		
			int prioCount=sp.addPref(studPref);
	//
			ParamMapper maParamMapper= new ParamMapper(){
				public void mapParam(PreparedStatement pStmt) throws SQLException{ 
					pStmt.setString(1,studPref.getStudId());
					pStmt.setString(2,studPref.getPrefCourse().get(0).getCourseId());
					pStmt.setString(3,studPref.getPrefCourse().get(0).getPrefCourse());
				}
			};
			try {
				con = ch.establishConnection();//
				if(prioCount==1)
				{
					result=DBHelper.executeUpdate(con,SqlMapper.SAVE_COURSE_PREF,maParamMapper);
				}
				if(prioCount==2)
				{
					result=DBHelper.executeUpdate(con,SqlMapper.SAVE_COURSE_PREF,maParamMapper);
				}
				if(result<=0)
				{
					result=0;
				}
			}
			catch (DBFWException e){
				throw new CourseDAOException(e);
			}
//			finally{
			//v
			studPref.getPrefCourse().remove(0);
		}
		//^
			try{
				con.close();
			}
			catch (SQLException e){
				throw new CourseDAOException(e);
//				System.out.println(e);
			}
//		}
		return result;
//			return 8;//for test cases uncomment this.
	}	
		*/
		
		
		
		
		
		
		
	}
	
	

