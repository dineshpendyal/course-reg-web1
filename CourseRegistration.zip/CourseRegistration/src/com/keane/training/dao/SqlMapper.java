package com.keane.training.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.keane.dbfw.ResultMapper;
import com.keane.training.domain.User;
import com.keane.training.domain.Course;
import com.keane.training.domain.CoursePreference;
import com.keane.training.domain.Department;
import com.keane.training.domain.Professor;

public class SqlMapper {

	public static final String FETCH_USER = "select name,employeeId,technology,password from user_info where portalid=?";
	public static final String FETCH_AUSER = "select employeeId from user_info where portalid=?";
	public static final ResultMapper MAP_USER = new ResultMapper() {

		@Override
		public Object mapRows(ResultSet rs) throws SQLException {
			User user = new User();
			user.setPassword(rs.getString("password"));
			user.setEmployeeId(rs.getInt("employeeId"));
			return user;
			
		}
	};
	public static final ResultMapper MAP_AUSER = new ResultMapper() {

		@Override
		public Object mapRows(ResultSet rs) throws SQLException {
			User user = new User();
			user.setEmployeeId(rs.getInt("employeeId"));
			return user;
			
		}
	};
	public static final String ADD_USER = "insert into user_info(portalid,name,employeeId,technology,password) values(?,?,?,?,?)";
	public static final String FETCHCOUNTRY=
			"select * from country_081";
	public static final String FETCHPREFERENCE=
			"select courseId,PREFERENCE from StudCourses where STUDID=? ";
	public static final String FETCHCOURSE=
			"select * from course";
	public static final String FETCHDEPARTMENT=
			"select * from dept1";
	public static final String FETCHPROFESSOR=
			"select * from professor";
		public static final String FETCHCOUNTRYID=
			"select id,name from country_081 where id=? and name=?";
		public static final String INSERTPROFESSOR=
			"insert into professor  values(?,?,?)";//PROFESSOR_SEQ1.nextval
		public static final String INSERTCOURSE=
				"insert into course  values(?,?,?)";
		public static final String INSERTSTUDENT=
				"insert into student  values(?,?,?,?,?)";
		public static final String INSERTCOURSEPREFERENCE=
				"insert into studcourses  values(?,?,?)";
		
		
		//public static final String PROFESSOR_SEQUENCE="select PROFESSOR_SEQUENCE.nextval from dual";
		public static final String PROFESSOR_SEQUENCE="select PROFESSOR_SEQ1.nextval from dual";
		public static final String COURSE_SEQUENCE="select COURSE_SEQ1.nextval from dual";
		public static final ResultMapper COURSE_SEQ_MAP=new ResultMapper(){
			public Object mapRows(ResultSet rs) throws SQLException{
				return rs.getString(1);
			}
		};
		
		/*public static final ResultMapper COUNTRYMAPPER=
			new ResultMapper()
		{
			public Object mapRow(ResultSet rs) throws SQLException {
			int id=	rs.getInt(1);
			String name=rs.getString(2);
			Country c=new Country(id,name);
				return c;
			}//mapRow
			
		};//Anonymous class
*/		public static final ResultMapper DEPARTMENTMAPPER=
				new ResultMapper()
			{
				public Object mapRows(ResultSet rs) throws SQLException {
				String id=	rs.getString(1);
				String name=rs.getString(2);
				Department c=new Department(id,name);
					return c;
				}//mapRow
				
			};
			public static final ResultMapper PROFESSORMAPPER=
					new ResultMapper()
				{
					public Object mapRows(ResultSet rs) throws SQLException {
					String id=	rs.getString(1);
					String name=rs.getString(2);
					String deptid=rs.getString(3);
					Professor c=new Professor(id,name,deptid);
						return c;
					}//mapRow
					
				};
				public static final ResultMapper COURSEMAPPER=
						new ResultMapper()
					{
						public Object mapRows(ResultSet rs) throws SQLException {
						String id=	rs.getString(1);
						String name=rs.getString(2);
					    String profId=rs.getString(3);
						Course c=new Course(id,name,profId);
							return c;
						}//mapRow
						
					};
					/*public static final ResultMapper PREFERENCEMAPPER=
							new ResultMapper()
						{
							public Object mapRow(ResultSet rs) throws SQLException {
							String id=	rs.getString(1);
							//String cid=rs.getString(2);
							//String prefer=rs.getString(3);
				            CoursePreference cp=new CoursePreference(id);
								return cp;
							}//mapRow
							
						};*/
					public static final ResultMapper PREFERENCEMAPPER = new ResultMapper(){
						public Object mapRows(ResultSet rs) throws SQLException{
							CoursePreference cp=new CoursePreference(rs.getString("courseid"),rs.getString("preference"));
							return cp;
						}
					};
						
					static final ResultMapper PROFESSOR_MAP=new ResultMapper(){
						public Object mapRows(ResultSet rs) throws SQLException{
							return rs.getString(1);
						}
					};
					static final ResultMapper COURSE_MAP=new ResultMapper(){
						public Object mapRows(ResultSet rs) throws SQLException{
							return rs.getString(1);
						}
					};
							
							/*static final ResultMapper PROFESSOR_MAP=new ResultMapper(){
								public Object mapRow(ResultSet rs) throws SQLException{
									return rs.getString(1);
								}
							};*/

}

//create table user_info(name varchar2(20),employeeId int,technology varchar2(20),password varchar2(20),portalid int)

