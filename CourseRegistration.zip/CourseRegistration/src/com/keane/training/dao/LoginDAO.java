package com.keane.training.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.keane.dbcon.ConnectionHolder;
import com.keane.dbcon.DBConnectionException;
import com.keane.dbfw.DBFWException;
import com.keane.dbfw.DBHelper;
import com.keane.dbfw.ParamMapper;
import com.keane.training.domain.User;
import com.keane.training.dao.SqlMapper;

public class LoginDAO {
	static Logger log = Logger.getLogger(LoginDAO.class);

	public List validateUser(final int pid) throws DAOAppException {
		List res = null;
		ConnectionHolder ch = null;
		Connection con = null;
		try {
			ch = ConnectionHolder.getInstance();
			con = ch.getConnection();
			ParamMapper paramMapper = new ParamMapper() {

				@Override
				public void mapParams(PreparedStatement pStmt)
						throws SQLException {
					pStmt.setInt(1, pid);
				}
			};
			res = DBHelper.executeSelect(con, SqlMapper.FETCH_USER,
					paramMapper, SqlMapper.MAP_USER);

		} catch (DBConnectionException e) {
			log.error(e);
			throw new DAOAppException(e);
		} catch (DBFWException e) {
			throw new DAOAppException(e);
		}
		return res;

	}
	public User validateAUser(final int pid) throws DAOAppException {
		//List res = null;
		ConnectionHolder ch = null;
		Connection con = null;
		List res=null;
		User us=null;
		try {
			ch = ConnectionHolder.getInstance();
			con = ch.getConnection();
			ParamMapper userParamMapper = new ParamMapper() {

				@Override
				public void mapParams(PreparedStatement pStmt)
						throws SQLException {
					pStmt.setInt(1, pid);
				}
			};
			res = DBHelper.executeSelect(con, SqlMapper.FETCH_AUSER,
					userParamMapper, SqlMapper.MAP_AUSER);
			us=(User)res;
			/*Iterator itr=res.iterator();
			
			while(itr.hasNext())
			{
				 us=(User)itr.next();
			}
			*/

		} catch (DBConnectionException e) {
			log.error(e);
			throw new DAOAppException(e);
		} catch (DBFWException e) {
			throw new DAOAppException(e);
		}
		return us;

	}
	
	/*public static List getCountry(final int cid,final String cname)
	{
		ConnectionHolder ch=null;
		Connection con=null;
		List country=null;
		
		try {
				ch=ConnectionHolder.getInstance();
				con=ch.getConnection();
			final ParamMapper COUNTRYPMAPPER=new ParamMapper()
			{

				public void mapParam(PreparedStatement preStmt) throws SQLException {
				preStmt.setInt(1,cid);
				preStmt.setString(2,cname);						
				}
				
			};//ananymous class
			
		country=DBHelper.executeSelect
		(con,SQLMapper.FETCHCOUNTRYID,SQLMapper.COUNTRYMAPPER, COUNTRYPMAPPER );		
	
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return country;
		
	}//getcountry*/
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
