package com.keane.training.dao;

public class CourseDAOException extends Throwable {

	public CourseDAOException(String message,Throwable cause){
		super(message,cause);
	}
	public CourseDAOException(String message){
		super(message);
	}
	
	
	
	public CourseDAOException(){
		super();
	}
	public CourseDAOException(Throwable cause){
		super(cause);
	}
	
	
}
