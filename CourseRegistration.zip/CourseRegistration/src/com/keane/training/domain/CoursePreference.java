package com.keane.training.domain;

public class CoursePreference {
	private String CourseId;
	private String PrefCourse;
	public CoursePreference(String courseId, String prefCourse) {
		super();
		CourseId = courseId;
		PrefCourse = prefCourse;
	}
	public CoursePreference() {
		// TODO Auto-generated constructor stub
	}
	public CoursePreference(String id) {
		// TODO Auto-generated constructor stub
		CourseId=id;
	}
	public String getCourseId() {
		return CourseId;
	}
	public void setCourseId(String courseId) {
		CourseId = courseId;
	}
	public String getPrefCourse() {
		return PrefCourse;
	}
	public void setPrefCourse(String prefCourse) {
		PrefCourse = prefCourse;
	}
	
}
