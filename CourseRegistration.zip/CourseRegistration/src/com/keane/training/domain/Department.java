package com.keane.training.domain;

public class Department {
	private String DepId;
	private String DeptName;
	public Department(String depId, String deptName) {
		super();
		DepId = depId;
		DeptName = deptName;
	}
	public String getDepId() {
		return DepId;
	}
	public void setDepId(String depId) {
		DepId = depId;
	}
	public String getDeptName() {
		return DeptName;
	}
	public void setDeptName(String deptName) {
		DeptName = deptName;
	}
	

}