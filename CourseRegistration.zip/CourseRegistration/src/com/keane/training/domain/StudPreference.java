package com.keane.training.domain;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.keane.dbcon.DBConnectionException;
import com.keane.dbfw.DBFWException;
import com.keane.training.dao.CourseDAOException;
import com.keane.training.dao.StudentDAO;


public class StudPreference {
private String studId;
private List<CoursePreference> prefCourse;

public String getStudId() {
	return studId;
}
public void setStudId(String studId) {
	this.studId = studId;
}
public List<CoursePreference> getPrefCourse() {
	return prefCourse;
}
public void setPrefCourse(List<CoursePreference> prefCourse) {
	this.prefCourse = prefCourse;
}




public StudPreference() {
	super();
}
public StudPreference(String studId, List<CoursePreference> prefCourse) {
	this.studId = studId;
	this.prefCourse = prefCourse;
}



public int addPref(StudPreference studPref) throws CourseDAOException, DBConnectionException, DBFWException{
	java.util.List<CoursePreference>lis=new ArrayList<CoursePreference>();
	int primarycount=0;
	int secondarycount=0;
	StudentDAO sd=new StudentDAO();
	lis=sd.getPrefCourses(studPref.getStudId());
	Iterator<CoursePreference> it=lis.iterator();
	CoursePreference cp=new CoursePreference();
	
	while(it.hasNext()){
		cp=(CoursePreference)it.next();
		if(cp.getPrefCourse().equalsIgnoreCase("pri")){
			primarycount++;
		}
		if(cp.getPrefCourse().equalsIgnoreCase("sec")){
			secondarycount++;
		}
	}
	
	if(primarycount<4 && studPref.getPrefCourse().get(0).getPrefCourse().equalsIgnoreCase("pri"))
	 {
		 return 1;
	 }
	 if(secondarycount<2 && studPref.getPrefCourse().get(0).getPrefCourse().equalsIgnoreCase("sec"))
	 {
		 return 2;
	 }
	return 0;
}
}
	
	
	
	
	

