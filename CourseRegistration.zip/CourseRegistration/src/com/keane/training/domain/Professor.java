package com.keane.training.domain;

public class Professor {
	private String ProfId;
	private String ProfName;
	private String DeptId;
	public Professor(String profId, String profName, String deptId) {
		super();
		ProfId = profId;
		ProfName = profName;
		DeptId = deptId;
	}
	public Professor(String profName, String deptId) {
		// TODO Auto-generated constructor stub
		this.ProfName=profName;
		this.DeptId=deptId;
	}
	public String getProfId() {
		return ProfId;
	}
	public void setProfId(String profId) {
		ProfId = profId;
	}
	public String getProfName() {
		return ProfName;
	}
	public void setProfName(String profName) {
		ProfName = profName;
	}
	public String getDeptId() {
		return DeptId;
	}
	public void setDeptId(String deptId) {
		DeptId = deptId;
	}
	
}

