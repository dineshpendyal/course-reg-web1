package com.keane.training.domain;

public class Course {
	public Course(String courseName, String profId) {
		super();
		CourseName = courseName;
		ProfId = profId;
	}
	private String CourseId;
	private String CourseName;
	private String ProfId;
	public Course(String courseId, String courseName, String profId) {
		super();
		CourseId = courseId;
		CourseName = courseName;
		ProfId = profId;
	}
	public String getCourseId() {
		return CourseId;
	}
	public void setCourseId(String courseId) {
		CourseId = courseId;
	}
	public String getCourseName() {
		return CourseName;
	}
	public void setCourseName(String courseName) {
		CourseName = courseName;
	}
	public String getProfId() {
		return ProfId;
	}
	public void setProfId(String profId) {
		ProfId = profId;
	}
	
	
}

