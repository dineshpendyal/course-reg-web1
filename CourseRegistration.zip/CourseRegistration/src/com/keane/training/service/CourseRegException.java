package com.keane.training.service;

public class CourseRegException extends Throwable {
public CourseRegException(String message,Throwable cause)
{
	super(message,cause);
}
public CourseRegException(String message)
{
	super(message);
}
}
