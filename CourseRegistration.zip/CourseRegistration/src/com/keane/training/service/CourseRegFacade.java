package com.keane.training.service;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.keane.dbcon.DBConnectionException;
import com.keane.dbfw.DBFWException;
import com.keane.training.dao.AdminDAO;
import com.keane.training.dao.CourseDAOException;
import com.keane.training.dao.StudentDAO;
import com.keane.training.dao.UserDAO;
import com.keane.training.domain.Course;
import com.keane.training.domain.CoursePreference;
import com.keane.training.domain.Department;
import com.keane.training.domain.Professor;
import com.keane.training.domain.StudPreference;
import com.keane.training.domain.Student;
import com.keane.training.domain.User;

public class CourseRegFacade {
/*public User validateUser(String userId,String passwd) throws CourseRegException, SQLException, CourseDAOException, ClassNotFoundException
{    UserDAO userdao=new UserDAO();
     User recdUser;
	     recdUser=userdao.validateUser(userId, passwd);
	     return recdUser;
}*/
public String saveProfessor(Professor professor) throws CourseRegException, CourseDAOException, DBConnectionException
{   AdminDAO admin=new AdminDAO();
    String id=admin.saveProfessor(professor);
   return id;
	
}
public String saveStudent(Student sd) throws CourseRegException, CourseDAOException, DBConnectionException
{   AdminDAO admin=new AdminDAO();
    String id=admin.saveStudent(sd);
   return id;
	
}
public String saveCourse(Course c) throws CourseRegException, CourseDAOException, DBConnectionException
{
	AdminDAO admin=new AdminDAO();
    String courseId=admin.saveCourse(c);
   return courseId;
}
public List<Professor> getAllProf() throws CourseRegException, DBFWException, DBConnectionException, CourseDAOException
{    List<Professor> professors;
	 AdminDAO admin=new AdminDAO();
     professors= admin.getAllProf();
     return professors;
}
public List<Department> getAllDept() throws CourseRegException, DBFWException, DBConnectionException, CourseDAOException
{
	List<Department> departments;
	AdminDAO admin=new AdminDAO();
   departments= admin.getAllDept();
   return departments;
}
public List<Course> getAllCourse() throws CourseRegException, DBFWException, DBConnectionException, CourseDAOException
{     List<Course> courses;
       StudentDAO studentDao=new StudentDAO();
       courses=studentDao.getAllCourse();
       return courses;
	
}////-----------------------rectify this
public int savePrefCourses(StudPreference studPref) throws CourseRegException, CourseDAOException
{
    StudentDAO studentDao=new StudentDAO();
    int numRows=studentDao.saveCoursePref(studPref);
    return numRows;
    
    
}
public List<CoursePreference> getPrefCourses(String studId)  throws CourseRegException, DBFWException, DBConnectionException, CourseDAOException
{   StudentDAO studao=new StudentDAO();
java.util.List<CoursePreference> cli=new ArrayList<CoursePreference>();
try{
	cli=studao.getPrefCourses(studId);
}
catch(CourseDAOException e){
	throw new CourseRegException("Invalid");
//	System.out.println("exception in crf: "+e);
}
return cli;
}


}
