package com.keane.training.web.handlers;


import com.keane.training.service.*;


//import java.beans.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;

import com.keane.dbcon.DBConnectionException;
import com.keane.dbfw.DBFWException;
import com.keane.mvc.HttpRequestHandler;
import com.keane.training.dao.AdminDAO;
//import com.keane.training.dao.CourseDAO;
import com.keane.training.dao.CourseDAOException;
import com.keane.training.dao.DAOAppException;
import com.keane.training.dao.RegisterDAO;
import com.keane.training.dao.StudentDAO;
import com.keane.training.domain.Course;
import com.keane.training.domain.Professor;
import com.keane.training.domain.User;
import com.keane.training.domain.CoursePreference;
import com.keane.training.domain.StudPreference;

public class AddPreference implements HttpRequestHandler {
	static Logger log = Logger.getLogger(RegisterUser.class);

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try{
			String isExists;
			StudentDAO dao = new StudentDAO();
			String sid=request.getParameter("txtStudentId");
			String cid=request.getParameter("txtCourseId");
			String pref=request.getParameter("txtPreferences");
			CoursePreference cp=new CoursePreference(cid,pref);
			List<CoursePreference>lcp=new ArrayList<CoursePreference>();
			lcp.add(cp);
			StudPreference sp=new StudPreference(sid,lcp);
			isExists = sid;
			if (isExists==null)
			{
				log.info("Professor already registered");
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("..\\pages\\SavePreferences1.jsp");
				request.setAttribute("Err",
						"Course already registered with the system");
				dispatcher.forward(request, response);
			}
			else
			{
				System.out.println("hi hello");
				dao.saveCoursePref(sp);
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("StudentMenu.jsp");
				request.setAttribute("Success",
						"Course successfully registered with the system");
				dispatcher.forward(request, response);
			}
		
		}catch (CourseDAOException e) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp");
			request.setAttribute("Err", e.getMessage());
			dispatcher.forward(request, response);
		}
	}}
