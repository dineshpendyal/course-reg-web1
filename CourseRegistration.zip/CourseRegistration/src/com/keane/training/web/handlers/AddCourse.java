package com.keane.training.web.handlers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.keane.dbcon.DBConnectionException;
import com.keane.mvc.HttpRequestHandler;
import com.keane.training.dao.AdminDAO;
import com.keane.training.dao.CourseDAOException;
import com.keane.training.dao.DAOAppException;
import com.keane.training.dao.LoginDAO;
import com.keane.training.domain.User;
import com.keane.training.domain.Professor;
import com.keane.training.service.CourseRegException;
import com.keane.training.service.CourseRegFacade;
import com.keane.training.domain.Course;

public class AddCourse implements HttpRequestHandler {

	public static Logger log = Logger.getLogger(Login.class);

	public void handle(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String courseId=request.getParameter("courId");
		String courseName = request.getParameter("txtCourseName");
		String profId=request.getParameter("sltProfessor");
		AdminDAO dao = new AdminDAO();
		AdminDAO admin=new AdminDAO();
		CourseRegFacade c=new CourseRegFacade();
		 Course course=new Course( courseId,courseName, profId);
         CourseRegFacade course1=new CourseRegFacade();
         //course1.saveCourse(course);
        //Professor p=new Professor(profName, dept); 
         
 try {
			String courseId1=c.saveCourse(course);
			request.setAttribute("Name1", courseId1);
			RequestDispatcher dispatcher = request.getRequestDispatcher("AddCourseSucess.jsp");
 			dispatcher.forward(request, response);
 		
 							
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CourseRegException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CourseDAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    //String id=admin.saveProfessor(professor);
	   //return id;
		
		}
	}
