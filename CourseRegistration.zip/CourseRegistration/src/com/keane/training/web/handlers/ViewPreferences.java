package com.keane.training.web.handlers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.keane.dbcon.DBConnectionException;
import com.keane.dbfw.DBFWException;
import com.keane.mvc.HttpRequestHandler;
import com.keane.training.dao.CourseDAOException;
import com.keane.training.service.CourseRegException;
import com.keane.training.service.CourseRegFacade;

public class ViewPreferences implements HttpRequestHandler {

	public static Logger log = Logger.getLogger(Login.class);

	public void handle(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		 List cli; 
		 String id=request.getParameter("studentId1");
	     CourseRegFacade pref1=new CourseRegFacade();
	    try {
			cli =pref1.getPrefCourses(id);
			/*Iterator itr=courses.iterator();
			while(itr.hasNext())
			{
				Course c=(Course)itr.next();*/
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("ViewPreferences.jsp");
			request.setAttribute("list", cli);
			dispatcher.forward(request, response);
				/*System.out.print(c.getCourseId()+"  ");
				System.out.print(c.getCourseName()+" ");
				System.out.print(c.getProfId()+"   ");
				System.out.println();
	                            		*/	
			
	        
		} catch (DBFWException | DBConnectionException | CourseRegException
				| CourseDAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*Iterator itr=courses.iterator();
		while(itr.hasNext())
		{
			Course c=(Course)itr.next();
			System.out.print(c.getCourseId()+"  ");
			System.out.print(c.getCourseName()+" ");
			System.out.print(c.getProfId()+"   ");
			System.out.println();
                            			
		
        }*/
		
			
		
		}
}
