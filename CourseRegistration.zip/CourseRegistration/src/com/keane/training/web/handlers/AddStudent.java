package com.keane.training.web.handlers;



import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.keane.dbcon.DBConnectionException;
import com.keane.mvc.HttpRequestHandler;
import com.keane.training.dao.AdminDAO;
import com.keane.training.dao.CourseDAOException;
import com.keane.training.dao.DAOAppException;
import com.keane.training.dao.LoginDAO;
import com.keane.training.domain.User;
import com.keane.training.domain.Professor;
import com.keane.training.service.CourseRegException;
import com.keane.training.service.CourseRegFacade;
import com.keane.training.domain.Course;
import com.keane.training.domain.Student;

public class AddStudent implements HttpRequestHandler {

	public static Logger log = Logger.getLogger(Login.class);

	public void handle(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String studId=request.getParameter("studId");
		 String studentName = request.getParameter("txtCourseName");
		 String addressed=request.getParameter("txtAddress");
		//String profId=request.getParameter("txtAddress");
		 String degree=request.getParameter("txtDegree");
		 Date dob;
		 Student st;
		try {
			dob = new SimpleDateFormat("dd/MM/yyyy").parse(request.getParameter("txtDOB"));
			AdminDAO dao = new AdminDAO();
			AdminDAO admin=new AdminDAO();
			CourseRegFacade c=new CourseRegFacade();
		  st=new Student(studId,studentName, addressed,dob,degree);
		  CourseRegFacade cdf=new CourseRegFacade();
		  try {
			  
			cdf.saveStudent(st);
			RequestDispatcher dispatcher = request
					.getRequestDispatcher("AddStudentSucess.jsp");
			request.setAttribute("Name", studId);
			dispatcher.forward(request, response);
			
			
			
		} catch (DBConnectionException | CourseRegException
				| CourseDAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
		  
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		/* AdminDAO dao = new AdminDAO();
			AdminDAO admin=new AdminDAO();
			CourseRegFacade c=new CourseRegFacade();
		 Student st=new Student(studId,studentName, addressed,dob,degree);*/
         
       
        

	    //String id=admin.saveProfessor(professor);
	   //return id;
		
		}
	}

