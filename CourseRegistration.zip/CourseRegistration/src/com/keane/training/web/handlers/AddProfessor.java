package com.keane.training.web.handlers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.keane.dbcon.DBConnectionException;
import com.keane.mvc.HttpRequestHandler;
import com.keane.training.dao.AdminDAO;
import com.keane.training.dao.CourseDAOException;
import com.keane.training.dao.DAOAppException;
import com.keane.training.dao.LoginDAO;
import com.keane.training.domain.User;
import com.keane.training.domain.Professor;
import com.keane.training.service.CourseRegException;
import com.keane.training.service.CourseRegFacade;

public class AddProfessor implements HttpRequestHandler {

	public static Logger log = Logger.getLogger(Login.class);

	public void handle(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String profName = request.getParameter("txtProfName");
		String dept=request.getParameter("sltDept");
		AdminDAO dao = new AdminDAO();
		AdminDAO admin=new AdminDAO();
		CourseRegFacade c=new CourseRegFacade();
        Professor p=new Professor(profName, dept); 
        try {
			String profId=c.saveProfessor(p);
			if (!profId.equals("")) {
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("AddProfessorSucess.jsp");
				request.setAttribute("Name", profId);
				dispatcher.forward(request, response);

			} else {
				RequestDispatcher dispatcher = request
						.getRequestDispatcher("Login.jsp");
				request.setAttribute("Err",
						"username or password is incorrect");
				dispatcher.forward(request, response);
			}				
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CourseRegException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CourseDAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    //String id=admin.saveProfessor(professor);
	   //return id;
		
		}
	}